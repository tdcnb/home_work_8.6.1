

<?php 
 $p = 'Программирование это искуство!';
?>

<?php 
 $name = 'Игорь';
 $surname = 'Евстифеев';
 $city = 'Оренбург';
 $age = 57;
?>


<?php
include 'main.php';
?>

