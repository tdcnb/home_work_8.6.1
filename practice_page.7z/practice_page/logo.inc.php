    
                <div class="logo"> 
                <img src="img/icon.png" alt="php">
                </div>                                                 
        