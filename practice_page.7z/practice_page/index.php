

<?php 
 $p = 'У технарей неважно с дизайном!';
?>

<?php 
 $name = 'Игорь';
 $surname = 'Евстифеев';
 $city = 'Оренбург';
 $age = 57;
?>


<?php
include 'main.php';
?>

