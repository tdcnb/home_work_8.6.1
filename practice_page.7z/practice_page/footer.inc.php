<div class="footer">
            <h2>физик изучает программирование</h2>
        </div>